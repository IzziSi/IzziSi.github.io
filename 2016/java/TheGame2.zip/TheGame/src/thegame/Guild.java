/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thegame;

/**
 *
 * @author Administrator
 */
public class Guild {
    private String name;
    private int ID;
    private int abilities;
    
    public Guild() {
    name = "Rogue";
    ID = 00;
    }
}
